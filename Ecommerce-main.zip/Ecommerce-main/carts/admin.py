from django.contrib import admin
from carts.models import Cart, CartItems, Coupon

admin.site.register(Cart)
admin.site.register(CartItems)
